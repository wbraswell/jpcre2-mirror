#!/bin/sh
autoreconf -v -i
#autoreconf --force --install
